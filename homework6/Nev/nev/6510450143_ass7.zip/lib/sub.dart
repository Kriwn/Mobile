import 'package:flutter/material.dart';

class Detail extends StatelessWidget {
  const Detail(
      {Key? key,
      required this.name,
      required this.image,
      required this.detail})
      : super(key: key);

  final String name;
  final String image;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromRGBO(83, 151, 193, 1),
          title: Text(
            name,
          ),
        ),
        body:  Container(
          child:ListView(
            children: [
            SizedBox(
              child: Image.asset("assets/menuimages/$image"),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              child: Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text(detail,
                style: const TextStyle(fontSize: 30),),
              ),
            )
            ],
          ),
        ));
  }
}

class Favorite extends StatelessWidget {
  Favorite({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Not use"),
    );
  }
}

class Suggest extends StatelessWidget {
  Suggest({super.key});


  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(2.0, 10.0, 2.0 , 10.0),
      children: <Widget>[
        ProductBox(name: "Hawaiian", description: "Hawaiian pizza", price: 5.00, image: "hawaiian.jpg"),
        ProductBox(name: "Pepperoni", description: "Pepperoni pizza", price: 500, image: "pepperoni.jpg"),
      ],
      );
  }
}


class ProductBox extends StatelessWidget {
  ProductBox({Key? key,required this.name, required this.description,required this.price, required this.image}): super(key: key);

  final String name;
  final String description;
  final double price;
  final String image;

  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(2),
      height: 120,
      child: Card(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
          Image.asset("assets/menuimages/$image"),
          Expanded(
            child:  Container(
              padding: const EdgeInsets.all(5),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Text(name,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(description),
                  Text("Price: $price"),
                ],
              ),
            ),
          )
          ],
        ),
      )
    );
  }
}
