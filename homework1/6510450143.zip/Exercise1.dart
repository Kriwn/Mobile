void main() {
  double temprerature = 20;
  int value = 2;
  String pizza = 'pizza';
  String pasta = 'pasta';

  print("The temperature in ${temprerature.toInt()}\C");
  print("${value} plus ${value} makes ${value + value}");
  print("I like ${pizza} and ${pasta}");
}
